# Changelog

## [1.0.0] - 2025-04-17
- Initial release of Enigma v300 utility
- Added EnigmaC, Enigma2C, EnigmaMenu classes
- Supports encrypted license handling and menu interface
